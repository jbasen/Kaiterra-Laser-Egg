﻿using System.Reflection;

[assembly: AssemblyTitle("Kaiterra_Laser_Egg")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Kaiterra_Laser_Egg")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

