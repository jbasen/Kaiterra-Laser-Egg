﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;

namespace Kaiterra_Laser_Egg
{

	public delegate void DelegateFn(SimplSharpString Collection_DateTime, short PM25_Valid, 
		short PM10_Valid, short humidity_valid, short temp_valid, short rtvoc_valid, short co2_valid,
		SimplSharpString PM25_Display, SimplSharpString PM10_Display, SimplSharpString humidity_Display, 
		SimplSharpString temp_Display, SimplSharpString rtvoc_Display, SimplSharpString co2_Display, 
		short PM25, short PM10, short humidity, short temp, short rtvoc, short co2);

	public class Kaiterra_Integration
	{
		public DelegateFn callback_fn { get; set; }

		//****************************************************************************************
		// 
		//  Kaiterra_Integration	-	Constructor
		// 
		//****************************************************************************************
		public Kaiterra_Integration()
		{
		}

		#region Declarations
		private string API_Key;													//API Key for communications with cloud
		private string Device_ID;												//ID of Device to collect data from
		private bool Degrees_In_Fareinheit;										//true if temperature to be converted to Fareinheit
		private long delay_between_calculations = 1800000;						// 30 minute delay in msec 30 minutes * 60 seconds * 1000 msec/sec
		private CTimer cTimer = null;											//timer thread for collecting data 

		private string PM25_S;													//pm 25 data collected
		private string PM10_S;													//pm 10 data collected
		private string Humidity_S;												//humidity data collected
		private string Temperature_S;											//temperature data collected
		private string RTVOC_S;													//total voc data collected
		private string CO2_S;													//CO2 data collected

		private short PM25_Valid;												//1 if data element valid, otherwise 0
		private short PM10_Valid;												//1 if data element valid, otherwise 0
		private short Humidity_Valid;											//1 if data element valid, otherwise 0
		private short Temperature_Valid;										//1 if data element valid, otherwise 0
		private short RTVOC_Valid;												//1 if data element valid, otherwise 0
		private short CO2_Valid;												//1 if data element valid, otherwise 0

		private string PM25_Display_String;										//formated data for touch panel
		private string PM10_Display_String;										//formated data for touch panel
		private string Humidity_Display_String;									//formated data for touch panel
		private string Temperature_Display_String;								//formated data for touch panel
		private string RTVOC_Display_String;									//formated data for touch panel
		private string CO2_Display_String;										//formated data for touch panel
		private string Collection_DateTime_Display_String;						//formated data for touch panel

		private short PM25;														//data in numerical format
		private short PM10;														//data in numerical format
		private short Humidity;													//data in numerical format
		private short Temperature;												//data in numerical format
		private short RTVOC;													//data in numerical format
		private short CO2;														//data in numerical format

		#endregion

		//****************************************************************************************
		// 
		//  Initialization	-	
		// 
		//****************************************************************************************
		public void Initialization(string Device_ID_Part1, string Device_ID_Part2, string API_Key_Part1, string API_Key_Part2, short Fareinheit)
		{
			#region Check for proper configuration
			//Concatinate Device_ID and API_Key since they are too long for Simpl
			API_Key = API_Key_Part1 + API_Key_Part2;
			Device_ID = Device_ID_Part1 + Device_ID_Part2;

			if (Device_ID == "")
			{
				CrestronConsole.PrintLine("Missing Device ID for Kaiterra Laser Egg Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Device ID for Kaiterra Laser Egg Initialization");
				return;
			}
			if (API_Key == "")
			{
				CrestronConsole.PrintLine("Missing Key for Kaiterra Laser Egg Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Key for Kaiterra Laser Egg Initialization");
				return;
			}
			if (callback_fn == null)
			{
				CrestronConsole.PrintLine("Kaiterra Laser Egg-ERROR: Callback Function is NULL");
				Crestron.SimplSharp.ErrorLog.Error("Kaiterra Laser Egg-ERROR: Callback Function is NULL");
				return;
			}
			#endregion

			if (Fareinheit == 1)
			{
				Degrees_In_Fareinheit = true;
			}
			else
			{
				Degrees_In_Fareinheit = false;
			}


			#region Start Timer to Get Data Every 30 Minutes

			if (cTimer == null)
			{
				try
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Main_Timer_Thread);
					cTimer = new CTimer(Main_Timer_Thread, null, 0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("Kaiterra Laser Egg-Can't create timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Kaiterra Laser Egg-Can't create timer thread: " + e + "\n"));
					return;
				}
			}
			else
			{
				try
				{
					//restart timer that was previously stopped
					cTimer.Reset(0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("Kaiterra Laser Egg-Can't restart timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Kaiterra Laser Egg-Can't restart timer thread: " + e + "\n"));
					return;
				}
			}

			#endregion
		}
		//****************************************************************************************
		// 
		//  Main_Timer_Thread	-	
		// 
		//****************************************************************************************
		private void Main_Timer_Thread(Object unused)
		{
			string url, s;
			HttpsClientResponse httpsResponse;

			#region get Kaiterra Laser Egg data
			try
			{
				url = "https://api.origins-china.cn/v1/lasereggs/" + Device_ID + "?key=" + API_Key;
				httpsResponse = Send_Message_Get(url);
				s = httpsResponse.ContentString;
				CrestronConsole.PrintLine("Kaiterra Laser Egg-Response datapoint = " + s);//tester

				Parse_Data(s);

				//Send Data Back to Simpl
				callback_fn(Collection_DateTime_Display_String, PM25_Valid, PM10_Valid, Humidity_Valid, Temperature_Valid, RTVOC_Valid, CO2_Valid, 
					PM25_Display_String, PM10_Display_String, Humidity_Display_String, Temperature_Display_String, RTVOC_Display_String, CO2_Display_String, 
					PM25, PM10, Humidity, Temperature, RTVOC, CO2);

				CrestronConsole.PrintLine("PM10_S = " + PM10_S);
				CrestronConsole.PrintLine("PM25_S = " + PM25_S);
				CrestronConsole.PrintLine("Humidity_S = " + Humidity_S);
				CrestronConsole.PrintLine("Temperature_S = " + Temperature_S);
				CrestronConsole.PrintLine("TVOC_S = " + RTVOC_S);
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("Kaiterra Laser Egg-Error Obtaining Kaiterra Laser Egg Datapoints");
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("Kaiterra Laser Egg-Error Obtaining Kaiterra Laser Egg Datapoints");
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}
		//****************************************************************************************
		// 
		//  Send_Message_Get	-	
		// 
		//****************************************************************************************
		private HttpsClientResponse Send_Message_Get(string url)
		{

			// Create the client
			HttpsClient httpsClient = new HttpsClient();

			//turn verification off, to stop it taking a dump on cert errors
			httpsClient.HostVerification = false;
			httpsClient.PeerVerification = false;

			//create the request, populate it
			HttpsClientRequest httpsRequest = new HttpsClientRequest();

			httpsRequest.Url.Parse(url);
			httpsRequest.RequestType = RequestType.Get;

			//attempt to dispatch the request
			try
			{
				return httpsClient.Dispatch(httpsRequest);
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("Kaiterra Laser Egg-Error Sending Message (0) url = ", url);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("Kaiterra Laser Egg-Error Sending Message (0) url = ", url);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return null;
			}
		}
		//****************************************************************************************
		// 
		//  Parse_Data	-	
		// 
		//****************************************************************************************
		private void Parse_Data(string s)
		{
			string Collection_Date_Time_S, Collection_Date_S, Collection_Time_S, data;

			CrestronConsole.PrintLine("LaserEgg data = " + s);//tester

			#region Initialize Strings
			PM10_S = "";
			PM25_S = "";
			Humidity_S = "";
			Temperature_S = "";
			RTVOC_S = "";
			#endregion

			#region Parse Section
			Collection_Date_Time_S = Parse_Data_Substring(s, "\"info.aqi\":{\"ts\":\"", "Z");
			data = Parse_Data_Substring(s, "\"data\":{", "}") + ",";
			#endregion

			#region Parse Date/Time
			Collection_Date_Time_S = "D" + Collection_Date_Time_S + "Z";		//Add border characters for parsing routine			
			Collection_Date_S = Parse_Data_Substring(Collection_Date_Time_S, "D", "T");
			Collection_Time_S = Parse_Data_Substring(Collection_Date_Time_S, "T", "Z");
			DateTime d = DateTime.Parse(Collection_Date_S + " " + Collection_Time_S);
			Collection_DateTime_Display_String = d.ToLocalTime().ToString();
			CrestronConsole.PrintLine("Collection Date/Time = " + Collection_DateTime_Display_String);
			#endregion

			#region Parse data
			Humidity_S = Parse_Data_Substring(data, "\"humidity\":", ",");
			PM10_S = Parse_Data_Substring(data, "\"pm10\":", ",");
			PM25_S = Parse_Data_Substring(data, "\"pm25\":", ",");
			RTVOC_S = Parse_Data_Substring(data, "rtvoc\":", ",");
			Temperature_S = Parse_Data_Substring(data, "\"temp\":", ",");
			CO2_S = Parse_Data_Substring(data, "rco2 (ppm)\":", ",");
			#endregion

			#region Set Data Validity
			Humidity_Valid = Set_Element_Validity(Humidity_S);
			PM10_Valid = Set_Element_Validity(PM10_S);
			PM25_Valid = Set_Element_Validity(PM25_S);
			Temperature_Valid = Set_Element_Validity(Temperature_S);
			RTVOC_Valid = Set_Element_Validity(RTVOC_S);
			CO2_Valid = Set_Element_Validity(CO2_S);
			#endregion

			#region Numerical Conversion
			Humidity = Parsed_String_To_Short(Humidity_Valid, Humidity_S);
			PM10 = Parsed_String_To_Short(PM10_Valid, PM10_S);
			PM25 = Parsed_String_To_Short(PM25_Valid, PM25_S);
			RTVOC = Parsed_String_To_Short(RTVOC_Valid, RTVOC_S);
			CO2 = Parsed_String_To_Short(CO2_Valid, CO2_S);
			Temperature = Parsed_String_To_Short(Temperature_Valid, Temperature_S);

			if ((Degrees_In_Fareinheit == true) && (Temperature_Valid == 1))
			{
				double t = Convert.ToDouble(Temperature_S);
				t = (t * 1.8) + 32;
				t = Math.Round(t, 2);
				Temperature_S = t.ToString();
				Temperature = (short)Math.Round(t, 0);
			}
			#endregion

			#region Create Display Strings
			PM25_Display_String = Create_Display_String(PM25_Valid, PM25, "PM 2.5 = ", "");
			PM10_Display_String = Create_Display_String(PM10_Valid, PM10, "PM 10 = ", "");
			Humidity_Display_String = Create_Display_String(Humidity_Valid, Humidity, "Humidity = ", "%");
			if (Temperature_Valid == 1)
			{
				if (Degrees_In_Fareinheit == true)
				{
					Temperature_Display_String = Create_Display_String(Temperature_Valid, Temperature, "Temperature = ", " F");
				}
				else
				{
					Temperature_Display_String = Create_Display_String(Temperature_Valid, Temperature, "Temperature = ", " C");
				}
			}
			RTVOC_Display_String = Create_Display_String(RTVOC_Valid, RTVOC, "TVOC = ", " ppb");
			CO2_Display_String = Create_Display_String(CO2_Valid, CO2, "CO2 = ", " ppm");
			#endregion
		}
		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string id, string ending_char)
		{
			int index1, index2;

			//get index to start of value
			index1 = s.IndexOf(id, 0);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("Kaiterra Laser Egg-Unable to Locate " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Kaiterra Laser Egg-Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Kaiterra Laser Egg-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Kaiterra Laser Egg-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}
		//****************************************************************************************
		// 
		//  Set_Element_Validity	-	
		// 
		//****************************************************************************************
		short Set_Element_Validity(string s)
		{
			if (s == "")
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}
		//****************************************************************************************
		// 
		//  Parsed_String_To_Short	-	
		// 
		//****************************************************************************************
		short Parsed_String_To_Short(short Valid, string s)
		{
			if (Valid == 1)
			{
				double temp = Convert.ToDouble(s);
				temp = Math.Round(temp, 0);
				return Convert.ToInt16(temp);
			}
			else
			{
				return 0;
			}
		}
		//****************************************************************************************
		// 
		//  Create_Display_String	-	
		// 
		//****************************************************************************************
		string Create_Display_String(short Valid, short data, string beginning, string end)
		{
			if (Valid == 0)
			{
				return "";
			}
			else
			{
				return beginning + data.ToString() + end;
			}
		}
	}
}
